export const environment = {
  production: false,
  apiUrl: 'http://localhost:5000/',
};

