import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddrountineComponent } from './addrountine.component';

describe('AddrountineComponent', () => {
  let component: AddrountineComponent;
  let fixture: ComponentFixture<AddrountineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddrountineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddrountineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
