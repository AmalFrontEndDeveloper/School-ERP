import { Router } from '@angular/router';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { environment } from '../../../environments/environment';

export interface StudentClass {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-rountine',
  templateUrl: './rountine.component.html',
  styleUrls: ['./rountine.component.scss']
})
export class RountineComponent implements OnInit {
  displayedColumns: string[] = ['section','category','capacity','teacher_name','note','action'];
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  parentID: any;
  environment: any;
  studentfullinfo:any;

  studentclass: StudentClass[] = [
    {value: 'One', viewValue: 'One'},
    {value: 'Two', viewValue: 'Two'},
    {value: 'Three', viewValue: 'Three'}
  ];
  studentdetail: any;
  studentid: any;
  studentfulldetail: any;
    constructor(public router:Router,
    public _userService:UserService,
 ) { }

  ngOnInit() {
    this.environment=environment;
    this.allstudentdetail();
  }
  addsection(){
    this.router.navigate(['/addsyllabus']);
  }
  deletestudent(data){
    this.studentid = data;
    this._userService.DeleteStudent(this.studentid).pipe(first()).subscribe((res:any)=>{
      console.log(res);
      this.allstudentdetail();
    });
  }
  UpdatedStudent(studentdetail){
   this.studentfulldetail = studentdetail ;
   this.router.navigate(['/addrountine',this.studentfulldetail]);
  }

allstudentdetail(){
  this._userService.sectionInfo().pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.studentdetail = res;
    this.studentfullinfo =  new MatTableDataSource (this.studentdetail);
    console.log(this.studentfullinfo);
    this.studentfullinfo.paginator = this.paginator;
    this.studentfullinfo.sort = this.sort;
  });
}
applyFilter(filterValue: string) {
  this.studentfullinfo.filter = filterValue.trim().toLowerCase();
}
}
