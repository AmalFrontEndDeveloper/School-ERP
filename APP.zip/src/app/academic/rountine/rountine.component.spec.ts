import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RountineComponent } from './rountine.component';

describe('RountineComponent', () => {
  let component: RountineComponent;
  let fixture: ComponentFixture<RountineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RountineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RountineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
