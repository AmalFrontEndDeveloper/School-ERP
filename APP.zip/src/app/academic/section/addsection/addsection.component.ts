import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import { Router } from '@angular/router';
@Component({
  selector: 'app-addsection',
  templateUrl: './addsection.component.html',
  styleUrls: ['./addsection.component.scss']
})
export class AddsectionComponent implements OnInit {
  addsectionform:FormGroup
  classnames: any;
  teacherlist: any;
  constructor(public _userservice:UserService,public router:Router) { }

  ngOnInit() {
    this.addsection();
    this._userservice.Teachernames().pipe(first()).subscribe((res:any)=>{
     console.log(res);
     this.teacherlist = res.data;
    });
    this._userservice.ClassNames().pipe(first()).subscribe((res:any)=>{
      console.log(res);
      this.classnames = res.message;
      console.log(this.classnames);
    });
  }
  AddSection

addsection(){
  this.addsectionform = new FormGroup({
    section: new FormControl('',[Validators.required]),
    category: new FormControl('',[Validators.required]),
    capacity: new FormControl('',[Validators.required]),
    class: new FormControl('',[Validators.required]),
    teachername: new FormControl('',[Validators.required]),
    note: new FormControl('',[Validators.required]),
  })
}
addClassClick(){
  console.log(this.addsectionform.value.class);
}
addSectionClick(){
this._userservice.AddSection(
  this.addsectionform.value.section,
  this.addsectionform.value.category,
  this.addsectionform.value.capacity,
  this.addsectionform.value.class,
  this.addsectionform.value.teachername,
  this.addsectionform.value.note,
).pipe(first()).subscribe((res:any)=>{
  console.log(res);
  this.router.navigate(['/section']);
});
}

}
