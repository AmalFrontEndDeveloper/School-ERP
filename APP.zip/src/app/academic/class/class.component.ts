import { Component, OnInit } from '@angular/core';
export interface PeriodicElement {
  class: string;
  position: number;
  classnumeric: number;
  teachername: string;
  notes: string;
  action: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, class: 'Hydrogen', classnumeric: 1.0079, teachername: 'H',notes:'',action:''},
];
@Component({
  selector: 'app-class',
  templateUrl: './class.component.html',
  styleUrls: ['./class.component.scss']
})
export class ClassComponent implements OnInit {
  displayedColumns: string[] = ['position', 'class', 'classnumeric', 'teachername','notes','action'];
  dataSource = ELEMENT_DATA;
  constructor() { }

  ngOnInit() {
  }

}
