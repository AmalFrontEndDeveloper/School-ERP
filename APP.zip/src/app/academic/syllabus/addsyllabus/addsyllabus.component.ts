import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
@Component({
  selector: 'app-addsyllabus',
  templateUrl: './addsyllabus.component.html',
  styleUrls: ['./addsyllabus.component.scss']
})
export class AddsyllabusComponent implements OnInit {
  addsectionform:FormGroup
  constructor(public _userservice:UserService) { }

  ngOnInit() {
    this.addsection();
    this._userservice.Teachernames().pipe(first()).subscribe((res:any)=>{
     console.log(res);
    });
  }


addsection(){
  this.addsectionform = new FormGroup({
    section: new FormControl('',[Validators.required]),
    category: new FormControl('',[Validators.required]),
    capacity: new FormControl('',[Validators.required]),
    class: new FormControl('',[Validators.required]),
    teachername: new FormControl('',[Validators.required]),
    note: new FormControl('',[Validators.required]),
  })
}
addClassClick(){
  console.log(this.addsectionform.value.class);

}

}
