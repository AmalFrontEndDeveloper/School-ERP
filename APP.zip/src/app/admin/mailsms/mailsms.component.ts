import { Router } from '@angular/router';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { environment} from '../../../environments/environment'
@Component({
  selector: 'app-mailsms',
  templateUrl: './mailsms.component.html',
  styleUrls: ['./mailsms.component.scss']
})
export class MailsmsComponent implements OnInit {
  othersmsinfo: any;
  othersmsdetail:any;
  displayedColumns: string[] = ['name','phone','sendby','message','action'];
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  parentID: any;
  environment: any;
  teacherfulldetail: any;
  constructor(public router:Router,public _userService:UserService) { }
  ngOnInit() {
    this.environment=environment;
    this.OtherSmsDetails();
  }
  addparents(){
    this.router.navigate(['/addparents']);
  }
  applyFilter(filterValue: string) {
    this.othersmsdetail.filter = filterValue.trim().toLowerCase();
  }
 
OtherSmsDetails(){
  this._userService.OtherSmsDetail().pipe(first()).subscribe((res:any)=>{
    this.othersmsinfo = res.message;
    console.log(this.othersmsinfo);
    this.othersmsdetail =  new MatTableDataSource (this.othersmsinfo);
    console.log(this.othersmsdetail);
    this.othersmsdetail.paginator = this.paginator;
    this.othersmsdetail.sort = this.sort;
});
}
addmailsms(){
   this.router.navigate(['/addmailsms']);
  }
}
