import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MailsmsComponent } from './mailsms.component';

describe('MailsmsComponent', () => {
  let component: MailsmsComponent;
  let fixture: ComponentFixture<MailsmsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MailsmsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MailsmsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
