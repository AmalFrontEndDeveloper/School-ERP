import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import { Router } from '@angular/router';
@Component({
  selector: 'app-addmailsms',
  templateUrl: './addmailsms.component.html',
  styleUrls: ['./addmailsms.component.scss']
})
export class AddmailsmsComponent implements OnInit {
  addsmsform:FormGroup
  teachernames: any;
  constructor(public _userservice:UserService,public router:Router) { }
  ngOnInit() {
    this.addsmsform = new FormGroup({
      name: new FormControl('',[Validators.required]),
      phone: new FormControl('',[Validators.required]),
      sendby: new FormControl('',[Validators.required]),
      txtmsg: new FormControl('',[Validators.required]),

    })
    this._userservice.Teachernames().pipe(first()).subscribe((res:any)=>{
       console.log(res);
       this.teachernames = res.data;
       console.log(this.teachernames);
    });
  }
  addsmsClick(){
    console.log(this.addsmsform.value.phone);
    console.log(this.addsmsform.value.txtmsg);
    this._userservice.OtherSms(this.addsmsform.value.name,this.addsmsform.value.phone,this.addsmsform.value.sendby,this.addsmsform.value.txtmsg).pipe(first()).subscribe((res:any)=>{
      console.log(res);
      this.router.navigate(['/mailsms']);
    })
  }
}
