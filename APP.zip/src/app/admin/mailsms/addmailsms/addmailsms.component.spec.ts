import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddmailsmsComponent } from './addmailsms.component';

describe('AddmailsmsComponent', () => {
  let component: AddmailsmsComponent;
  let fixture: ComponentFixture<AddmailsmsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddmailsmsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddmailsmsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
