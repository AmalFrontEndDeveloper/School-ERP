import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-dashoard',
  templateUrl: './dashoard.component.html',
  styleUrls: ['./dashoard.component.scss']
})
export class DashoardComponent implements OnInit {
  studentCount: any;
  parentCount: any;
  teacherCount: any;

  constructor(public _userService:UserService) { }

  ngOnInit() {
    this._userService.StudentCount().pipe(first()).subscribe((res:any)=>{
      this.studentCount = res.message[0].StudentCount;
      console.log(this.studentCount);
    });
    this._userService.ParentsCount().pipe(first()).subscribe((res:any)=>{
      this.parentCount = res.message[0].StudentCount;
      console.log(this.parentCount);
    });
    this._userService.teacherCount().pipe(first()).subscribe((res:any)=>{
      this.teacherCount = res.message[0].StudentCount;
      console.log(this.teacherCount);
    });    
  }

}
