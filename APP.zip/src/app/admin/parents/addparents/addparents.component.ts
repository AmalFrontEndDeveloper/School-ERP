import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
export interface Food {
  value: string;
  viewValue: string;
}
import { FormGroup, FormControl, Validators, FormBuilder, ValidatorFn, AbstractControl } from '@angular/forms';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-addparents',
  templateUrl: './addparents.component.html',
  styleUrls: ['./addparents.component.scss']
})
export class AddparentsComponent implements OnInit {

  ParentsTitle = "Add Parents";
  addparentform:FormGroup;
  foods: Food[] = [
    {value: 'id1', viewValue: 'One'},
    {value: 'id2', viewValue: 'Two'},
    {value: 'id3', viewValue: 'Three'}
  ];
  parentlist: any[];
  fileupload: any;
  parentpic=[];
  parentprofile: any;
  constructor(public router:Router,public _userService:UserService) { }

  ngOnInit() {
    this.createstudent();
  }
  createstudent(){
    this.addparentform = new FormGroup({
      guardian_name:new FormControl('',[Validators.required]), 
      father_name:new FormControl('',[Validators.required]), 
      mother_name:new FormControl('',[Validators.required]), 
      father_profession:new FormControl('',[Validators.required]), 
      mother_profession:new FormControl('',[Validators.required]), 
      email:new FormControl('',[Validators.required]), 
      phone:new FormControl('',[Validators.required]), 
      address:new FormControl('',[Validators.required]), 
      // photo:new FormControl('',[Validators.required]), 
      username:new FormControl('',[Validators.required]), 
      password:new FormControl('',[Validators.required]), 
    });
  }
  addparentslist(){
    console.log(this.parentpic)
    this._userService.CreateParent(
      this.addparentform.value.guardian_name,
      this.addparentform.value.father_name,
      this.addparentform.value.mother_name,
      this.addparentform.value.father_profession,
      this.addparentform.value.mother_profession,
      this.addparentform.value.email,
      this.addparentform.value.phone,
      this.addparentform.value.address,
      this.parentpic,
      this.addparentform.value.username,
      this.addparentform.value.password,
      ).pipe(first()).subscribe((res:any)=>{
     console.log(res);
     this.router.navigate(['/parents']);
    });
  
  }
  imageupload(file: FileList) {
    this.fileupload =file.item(0);
    console.log(this.fileupload.name);
    this._userService.ParentsuploadImg(this.fileupload).pipe(first()).subscribe((res)=>{
      console.log(res);
      this.parentprofile = res;
      this.parentpic.push(this.parentprofile.file);
      console.log(this.parentpic);
    });
}

}
