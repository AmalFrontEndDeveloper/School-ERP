import { Router } from '@angular/router';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { environment} from '../../../environments/environment';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-parents',
  templateUrl: './parents.component.html',
  styleUrls: ['./parents.component.scss']
})
export class ParentsComponent implements OnInit {
  parentinfo: any;
  parentdetail:any;
  displayedColumns: string[] = ['photo','guardian_name','email','action'];
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  parentID: any;
  environment: any;
  constructor(public router:Router,public _userService:UserService) { }
  ngOnInit() {
    this.environment=environment;
    this.ParentDetails();
  }
  addparents(){
    this.router.navigate(['/addparents']);
  }
  applyFilter(filterValue: string) {
    this.parentdetail.filter = filterValue.trim().toLowerCase();
  }
  DeleteParentClick(data){


    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this imaginary file!',
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        Swal.fire(
          'Deleted!',
          'Your imaginary file has been deleted.',
          'success'
        )
        
        console.log(data);
        this.parentID = data ;
        this._userService.DeleteParent(this.parentID).pipe(first()).subscribe((res:any)=>{
            console.log(res);
            this.ParentDetails();
        });

      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'Your imaginary file is safe :)',
          'error'
        )
      }
    })



  } 
  
  
ParentDetails(){
  this._userService.parentsDetails().pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.parentinfo = res;
    this.parentdetail =  new MatTableDataSource (this.parentinfo);
    console.log(this.parentdetail);
    this.parentdetail.paginator = this.paginator;
    this.parentdetail.sort = this.sort;
});
}

}
