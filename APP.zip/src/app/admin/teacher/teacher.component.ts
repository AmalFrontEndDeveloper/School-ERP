import { Router } from '@angular/router';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { environment} from '../../../environments/environment'
import Swal from 'sweetalert2';

@Component({
  selector: 'app-teacher',
  templateUrl: './teacher.component.html',
  styleUrls: ['./teacher.component.scss']
})
export class TeacherComponent implements OnInit {
  teacherinfo: any;
  teacherdetail:any;
  displayedColumns: string[] = ['photo','username','email','status','action'];
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  parentID: any;
  environment: any;
  teacherfulldetail: any;
  constructor(public router:Router,public _userService:UserService) { }
  ngOnInit() {
    this.environment=environment;
    this.ParentDetails();
  }
  addparents(){
    this.router.navigate(['/addparents']);
  }
  applyFilter(filterValue: string) {
    this.teacherdetail.filter = filterValue.trim().toLowerCase();
  }
  DeleteTeacherClick(data){
    
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this imaginary file!',
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        Swal.fire(
          'Deleted!',
          'Your imaginary file has been deleted.',
          'success'
        )
        
        console.log(data);
        this.parentID = data ;
        this._userService.TeacherDelete(this.parentID).pipe(first()).subscribe((res:any)=>{
            console.log(res);
            this.ParentDetails();
        });

      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'Your imaginary file is safe :)',
          'error'
        )
      }
    })

 
  } 
  
  
ParentDetails(){
  this._userService.TeacherDetail().pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.teacherinfo = res;
    this.teacherdetail =  new MatTableDataSource (this.teacherinfo);
    console.log(this.teacherdetail);
    this.teacherdetail.paginator = this.paginator;
    this.teacherdetail.sort = this.sort;
});
}
  addteacher(){
   this.router.navigate(['/addteacher']);
  }
  UpdatedTeacherClick(teacherInfo){
   this.teacherfulldetail = teacherInfo ;
   this.router.navigate(['/addteacher',this.teacherfulldetail]);

  }
}
