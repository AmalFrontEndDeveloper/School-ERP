import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import { FormGroup, FormControl, Validators, FormBuilder, ValidatorFn, AbstractControl } from '@angular/forms';
import * as moment from 'moment';

export interface Gender {
  genderInfo: string;
}
@Component({
  selector: 'app-addteacher',
  templateUrl: './addteacher.component.html',
  styleUrls: ['./addteacher.component.scss']
})
export class AddteacherComponent implements OnInit {
  addteacherform:FormGroup;
  teacherphoto:any;
  teachername:any;
  designation:any;
  fileupload: any;
  teacherpic=[];
  teacherprofile: any;
  gender: Gender[] = [
    { genderInfo: 'Male'},
    { genderInfo: 'Female'},
  ];
  teacherupdateinfo: any;
  editteachername: any;
  editdesignation: any;
  editdob: any;
  selectgender: any;
  editreligion: any;
  editemail: any;
  editphoto: any;
  editaddress: any;
  editphone: any;
  editusername: any;
  editpassword: any;
  editjoining_date: any;
  dob: any;
  religion: any;
  password: any;
  username: any;
  joining_date: any;
  email: any;
  phone: any;
  address: any;
  dateofbirth: any;
  teacherid: any;
  constructor(public router:Router,
    public _userService:UserService,
    public route : ActivatedRoute
    ) { 
      this.route.params.subscribe(data => this.teacherupdateinfo = data);
       console.log(this.teacherupdateinfo);
         this.teachername = this.teacherupdateinfo.teacher_name;
         this.designation = this.teacherupdateinfo.designation;
         this.dob = this.teacherupdateinfo.date_of_birth;
         this.selectgender = this.teacherupdateinfo.gender;
         this.religion = this.teacherupdateinfo.religion;
         this.email = this.teacherupdateinfo.email;
         this.phone = this.teacherupdateinfo.phone;
         this.joining_date = this.teacherupdateinfo.joining_date;
         this.address = this.teacherupdateinfo.address;
         this.editphoto = this.teacherupdateinfo.photo;
         this.username = this.teacherupdateinfo.username;
         this.password = this.teacherupdateinfo.password;

    }
  ngOnInit() {
    this.addteachervali();
  }
  addteacherlist(){
    this._userService.AddTeacherAPI(
      this.addteacherform.value.teachername,
      this.addteacherform.value.designation,
      this.addteacherform.value.dob,
      this.addteacherform.value.gender,
      this.addteacherform.value.religion,
      this.addteacherform.value.email,
      this.addteacherform.value.phone,
      this.addteacherform.value.address,
      this.addteacherform.value.joining_date,
      this.teacherpic,
      this.addteacherform.value.username,
      this.addteacherform.value.password
      ).pipe(first()).subscribe((res:any)=>{
     console.log(res);
       this.router.navigate(['/teacher']);
    });
  }
addteachervali(){
  this.addteacherform = new FormGroup({
      teachername: new FormControl('',[Validators.required]),
      designation: new FormControl('',[Validators.required]),
      dob: new FormControl('',[Validators.required]),
      gender: new FormControl('',[Validators.required]),
      religion: new FormControl('',[Validators.required]),
      email: new FormControl('',[Validators.required]),
      phone: new FormControl('',[Validators.required]),
      address: new FormControl('',[Validators.required]),
      joining_date: new FormControl('',[Validators.required]),
      username: new FormControl('',[Validators.required]),
      password: new FormControl('',[Validators.required]),
  })
}  
imageupload(file: FileList) {
  this.fileupload =file.item(0);
  console.log(this.fileupload);
  this._userService.uploadImg(this.fileupload).pipe(first()).subscribe((res)=>{
    console.log(res);
    this.teacherprofile = res;
    this.teacherpic.push(this.teacherprofile.file);
    console.log(this.teacherpic);
  });
}
updateTeacher(data){
  this.dateofbirth= moment(this.addteacherform.value.dob).format('DD-MM-YYYY');
  console.log(data);
  this.teacherid = data ;
  console.log(this.dateofbirth);
  this._userService.TeacherUpdate(this.teacherid,this.teachername,this.designation,this.dob,this.selectgender
    ,this.religion,this.email ,this.phone ,this.address , this.joining_date ,this.editphoto, this.username, this.password 
    ).pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.router.navigate(['/teacher']);
  });
}

}
