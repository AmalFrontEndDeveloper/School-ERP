import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { UserService } from 'src/app/user.service';

@Component({
  selector: 'app-scheduler',
  templateUrl: './scheduler.component.html',
  styleUrls: ['./scheduler.component.scss']
})
export class SchedulerComponent implements OnInit {
  displayedColumns: string[] = ['elogName', 'resourceName', 'dateTime'];
  dataSource;
  tableForm: FormGroup;
  isScheduler: boolean;
  constructor(private formBuilder: FormBuilder,
    public userService: UserService) {
    this.userService.getPCAPlot(result => {
      this.dataSource = result.elogMappings;

      this.tableForm = this.formBuilder.group({
        scheduler: this.formBuilder.array([])
      })
      console.log('result', this.dataSource);
      console.log('tableForm', this.tableForm.value);
      if(this.tableForm&& this.tableForm.value && this.tableForm.value.scheduler && this.tableForm.value.scheduler.length > 0){
        this.isScheduler = true ;
      }
      this.setUsersForm();
      this.tableForm.get('scheduler').valueChanges.subscribe(scheduler => { 
        console.log('tableForm 111111111111111', this.tableForm);
        console.log('result11111111111111111111', this.dataSource);
        
          let filterData = scheduler.find(e=>e.dateTime=='');
          console.log('filterData', filterData)
          if(filterData){
            this.isScheduler = false ;
          } else {
            this.isScheduler = true ;
          }
       });
    });
  }

  ngOnInit() {

  }
  private setUsersForm() {
    const schedulerCrl = this.tableForm.get('scheduler') as FormArray;
    console.log('schedulerCrl', schedulerCrl);
    if (this.dataSource)
      this.dataSource.forEach((schedulerData) => {
        console.log('this.dataSource.forEach', schedulerData);
        schedulerCrl.push(this.setUsersFormArray(schedulerData))
      })
  };
  private setUsersFormArray(scheduler) {
    console.log('setUsersFormArray', scheduler);
    return this.formBuilder.group({
      elogName: [scheduler.elogName],
      resourceName: [scheduler.resourceName],
      dateTime: [scheduler.dateTime],
    });

  }

}
