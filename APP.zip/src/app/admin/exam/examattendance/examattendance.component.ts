import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-examattendance',
  templateUrl: './examattendance.component.html',
  styleUrls: ['./examattendance.component.scss']
})
export class ExamattendanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
