import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExamsheduleComponent } from './examshedule.component';

describe('ExamsheduleComponent', () => {
  let component: ExamsheduleComponent;
  let fixture: ComponentFixture<ExamsheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExamsheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExamsheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
