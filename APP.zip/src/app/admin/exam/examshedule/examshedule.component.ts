import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-examshedule',
  templateUrl: './examshedule.component.html',
  styleUrls: ['./examshedule.component.scss']
})
export class ExamsheduleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
