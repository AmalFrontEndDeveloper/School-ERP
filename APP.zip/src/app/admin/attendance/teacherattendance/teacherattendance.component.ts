import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teacherattendance',
  templateUrl: './teacherattendance.component.html',
  styleUrls: ['./teacherattendance.component.scss']
})
export class TeacherattendanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
