import { Router } from '@angular/router';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { environment } from '../../../../environments/environment'
import Swal from 'sweetalert2';
export interface StudentClass {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-studentattendance',
  templateUrl: './studentattendance.component.html',
  styleUrls: ['./studentattendance.component.scss']
})
export class StudentattendanceComponent implements OnInit {
  displayedColumns: string[] = ['photo','name','email','status','action'];
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  parentID: any;
  environment: any;
  studentfullinfo:any;

  studentclass: StudentClass[] = [
    {value: 'One', viewValue: 'One'},
    {value: 'Two', viewValue: 'Two'},
    {value: 'Three', viewValue: 'Three'}
  ];
  studentdetail: any;
  studentid: any;
  studentfulldetail: any;
    constructor(public router:Router,
    public _userService:UserService,
 ) { }

  ngOnInit() {
    this.environment=environment;
    this.allstudentdetail();
  }
  addstudentattendace(){
    this.router.navigate(['/addstudent_attendace']);
  }
  deletestudent(data){

    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this imaginary file!',
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        Swal.fire(
          'Deleted!',
          'Your imaginary file has been deleted.',
          'success'
        )
        
        this.studentid = data;
        this._userService.DeleteStudent(this.studentid).pipe(first()).subscribe((res:any)=>{
          console.log(res);
          this.allstudentdetail();
        });

      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'Your imaginary file is safe :)',
          'error'
        )
      }
    })

  }
  UpdatedStudent(studentdetail){
   this.studentfulldetail = studentdetail ;
   this.router.navigate(['/addstudent',this.studentfulldetail]);
  }
allstudentdetail(){
  this._userService.getAllStudentDetail().pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.studentdetail = res;
    this.studentfullinfo =  new MatTableDataSource (this.studentdetail);
    console.log(this.studentfullinfo);
    this.studentfullinfo.paginator = this.paginator;
    this.studentfullinfo.sort = this.sort;
  });
}
applyFilter(filterValue: string) {
  this.studentfullinfo.filter = filterValue.trim().toLowerCase();
}

}
