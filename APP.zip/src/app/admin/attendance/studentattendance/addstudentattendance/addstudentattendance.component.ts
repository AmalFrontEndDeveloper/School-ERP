import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
@Component({
  selector: 'app-addstudentattendance',
  templateUrl: './addstudentattendance.component.html',
  styleUrls: ['./addstudentattendance.component.scss']
})
export class AddstudentattendanceComponent implements OnInit {
  studentattendace:FormGroup
  classnames: any;
  selected_class_id: any;
  sectionnames: any;
  constructor(public _userservice:UserService) { }

  ngOnInit() {
    this.studentattendace = new FormGroup({
      classname: new FormControl('',[Validators.required]),
      setcion_names: new FormControl('',[Validators.required]),
      subjectname: new FormControl('',[Validators.required]),
      attendacedate: new FormControl('',[Validators.required]),
    })

    // this._userservice.Teachernames().pipe(first()).subscribe((res:any)=>{
    //    console.log(res);
    //    this.classnames = res.data;
    //    console.log(this.classnames);
    // });

this._userservice.ClassNames().pipe(first()).subscribe((res:any)=>{
  console.log(res);
  this.classnames = res.message ;
});
}
SelectClassClick(data){
console.log(data);
this.selected_class_id = data ;
this._userservice.sectionNames(this.selected_class_id).pipe(first()).subscribe((res:any)=>{
  console.log(res);
  this.sectionnames = res ;
});
}
// SelectsectionClick(data){
//   console.log("Select Section");
//   console.log(data);
//   this.selected_class_id = data ;
//   }
  addClassClick(){

  }

}
