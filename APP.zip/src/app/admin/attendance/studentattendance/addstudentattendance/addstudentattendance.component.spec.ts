import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddstudentattendanceComponent } from './addstudentattendance.component';

describe('AddstudentattendanceComponent', () => {
  let component: AddstudentattendanceComponent;
  let fixture: ComponentFixture<AddstudentattendanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddstudentattendanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddstudentattendanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
