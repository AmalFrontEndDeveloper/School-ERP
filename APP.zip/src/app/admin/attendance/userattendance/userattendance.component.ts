import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userattendance',
  templateUrl: './userattendance.component.html',
  styleUrls: ['./userattendance.component.scss']
})
export class UserattendanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
