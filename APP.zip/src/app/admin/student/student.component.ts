// import { Component, OnInit ,AfterViewInit, OnDestroy, ViewChild,ChangeDetectorRef,Inject } from '@angular/core';
// import { DataTableDirective } from 'angular-datatables';
import { Router } from '@angular/router';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { environment } from '../../../environments/environment'
import Swal from 'sweetalert2';

export interface StudentClass {
  value: string;
  viewValue: string;
}


@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.scss']
})
export class StudentComponent implements OnInit  {
  displayedColumns: string[] = ['photo','name','email','status','action'];
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  parentID: any;
  environment: any;
  studentfullinfo:any;

  studentclass: StudentClass[] = [
    {value: 'One', viewValue: 'One'},
    {value: 'Two', viewValue: 'Two'},
    {value: 'Three', viewValue: 'Three'}
  ];
  studentdetail: any;
  studentid: any;
  studentfulldetail: any;
    constructor(public router:Router,
    public _userService:UserService,
 ) { }

  ngOnInit() {
    this.environment=environment;
    // this.dtOptions = {
    //   pagingType: 'full_numbers',
    //   pageLength: 5,
    //   ordering:true,         
    //   processing: true
    // }
    // this._userService.getAllStudentDetail().pipe(first()).subscribe((res:any)=>{
    //   console.log(res);
    //   this.studentdetail = res;
    //         this.dtTrigger.next();
    // });
    this.allstudentdetail();
  }
  addstudent(){
    this.router.navigate(['/addstudent']);
  }
  deletestudent(data){

    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this imaginary file!',
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        Swal.fire(
          'Deleted!',
          'Your imaginary file has been deleted.',
          'success'
        )
        
        this.studentid = data;
        this._userService.DeleteStudent(this.studentid).pipe(first()).subscribe((res:any)=>{
          console.log(res);
          this.allstudentdetail();
        });

      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'Your imaginary file is safe :)',
          'error'
        )
      }
    })


  }
  UpdatedStudent(studentdetail){
   this.studentfulldetail = studentdetail ;
   this.router.navigate(['/addstudent',this.studentfulldetail]);
  }

allstudentdetail(){
  this._userService.getAllStudentDetail().pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.studentdetail = res;
    this.studentfullinfo =  new MatTableDataSource (this.studentdetail);
    console.log(this.studentfullinfo);
    this.studentfullinfo.paginator = this.paginator;
    this.studentfullinfo.sort = this.sort;
          // this.dtTrigger.next();
    // this.rerender();      
  });
}

// ngOnDestroy(): void {
//     this.dtTrigger.unsubscribe();
//   }
// rerender(): void {
// this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
//   dtInstance.destroy();
//   this.dtTrigger.next();
// });
// }
// ngAfterViewInit(): void {
//   this.dtTrigger.next();
// }
applyFilter(filterValue: string) {
  this.studentfullinfo.filter = filterValue.trim().toLowerCase();
}

}
