import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { UserService } from 'src/app/user.service';
import { FormGroup, FormControl, Validators, FormBuilder, ValidatorFn, AbstractControl } from '@angular/forms';
import * as moment from 'moment';
import { environment } from '../../../../environments/environment'

export interface Country {
  value: string;
  countryname: string;
}
export interface StdSection {
  value: string;
  sectionname: string;
}
export interface GroupType {
  value: string;
  groupname: string;
}

export interface Guardian {
  guardianname: string;
}
export interface Bloodgroup {
  bloodtype: string;
}

export interface Gender {
  genderInfo: string;
}
export interface Religion {
  religion: string;
}
export interface Classtype {
  classname: string;
}

@Component({
  selector: 'app-addstudent',
  templateUrl: './addstudent.component.html',
  styleUrls: ['./addstudent.component.scss']
})
export class AddstudentComponent implements OnInit {
  environment: any;
  countrylist: Country[] = [
    {value: 'id1', countryname: 'India'},
    {value: 'id2', countryname: 'Chinna'},
    {value: 'id3', countryname: 'Austrila'},
    {value: 'id3', countryname: 'Japense'},
    {value: 'id3', countryname: 'South Afriaka'},
    {value: 'id3', countryname: 'America'},
  ];
  SectionList: StdSection[] = [
    {value: 'section1', sectionname: 'A'},
    {value: 'section2', sectionname: 'B'},
    {value: 'section3', sectionname: 'C'},
    {value: 'section4', sectionname: 'D'},
    {value: 'section5', sectionname: 'E'},
    {value: 'section6', sectionname: 'F'},
  ];
  StdGroup: GroupType[] = [
    {value: 'Arts', groupname: 'Arts'},
    {value: 'Sciense', groupname: 'Sciense'},
    {value: 'Maths', groupname: 'Maths'},
    {value: 'Phisycs', groupname: 'Phisycs'},
    {value: 'Maths', groupname: 'Maths'},
  ];
  // selected = groupstd ;

  guardian: Guardian[] = [
    { guardianname: 'Amal'},
    { guardianname: 'Raj'},
    { guardianname: 'Priya'},
    { guardianname: 'Sam'},
    { guardianname: 'Jaison'},
    { guardianname: 'Mary'},
    { guardianname: 'Selvi'}

  ];
  classlist: Classtype[] = [
    { classname: 'One'},
    { classname: 'Two'},
    { classname: 'Three'},
    { classname: 'Four'},
    { classname: 'Five'},
    { classname: 'Six'},
    { classname: 'Seven'},
    { classname: 'Eight'},

  ];
  
  bloodgroup: Bloodgroup[] = [
    { bloodtype: 'A+'},
    { bloodtype: 'A-'},
    { bloodtype: 'B+'},
    { bloodtype: 'B-'},
    { bloodtype: 'AB+'},
    { bloodtype: 'AB-'},
    { bloodtype: 'A1B+'},
    { bloodtype: 'A1B-'},
    { bloodtype: 'A1B1+'},
    { bloodtype: 'A1B1-'},
    { bloodtype: 'O+'},
    { bloodtype: 'O-'}
  ]




  gender: Gender[] = [
    { genderInfo: 'Male'},
    { genderInfo: 'Female'},
  ];
  religion: Religion[] = [
    { religion: 'Hindu'},
    { religion: 'Christian'},
    { religion: 'Musliam'}
  ];

  
  studentname: any;
  studentphoto:any;
  userdetail: any;
  addstudentform: FormGroup;
  dateofbirth: any;
  studentprofile: any;
  fileupload: any;
  studentpic=[];
  studentinfo: any;
  groupstd=[];
  studentid: any;
  stdname: any;
  selectedguardianname: any;
  selectbloodgroup: any;
  selectgender: any;
  selectreligion: any;
  email: any;
  phone: any;
  address: any;
  state: any;
  selectcountry: any;
  selectclass: any;
  selectsection: any;
  selectgroup: any;
  roll: any;
  photo: any;
  extra_curricular_activities: any;
  remarks: any;
  username: any;
  password: any;
  dob: any;
  selectemail: any;
  registerno: any;
  stdroll: any;



  
  constructor(public router:Router,
    public _userService:UserService,
    public route: ActivatedRoute
    
    ) { 
      this.route.params.subscribe( data => this.studentinfo = data)
     console.log(this.studentinfo);
     this.stdname= this.studentinfo.name;
     this.selectedguardianname= this.studentinfo.guardianname;
     this.dob= this.studentinfo.dob;
    //  this.dob = new Date(this.dob);
     this.selectbloodgroup= this.studentinfo.bloodgroup;
     this.selectgender= this.studentinfo.gender;
     this.selectreligion= this.studentinfo.religion;
     this.email = this.studentinfo.email;
     this.phone= this.studentinfo.phone;
     this.address= this.studentinfo.address;
     this.state= this.studentinfo.state;
     this.selectcountry= this.studentinfo.country;
     this.selectclass= this.studentinfo.studentclass;
     this.selectsection= this.studentinfo.section;
     this.selectgroup= this.studentinfo.stdgroup;
     this.registerno= this.studentinfo.registerno;
     this.stdroll= this.studentinfo.roll;
     
     this.photo= this.studentinfo.photo;
     this.extra_curricular_activities= this.studentinfo.extra_curricular_activities;
     this.remarks= this.studentinfo.remarks;
     this.username= this.studentinfo.username;
     this.password= this.studentinfo.password;
      // this.groupstd.push(this.studentinfo.stdgroup);
    }

  ngOnInit() {


    this.environment=environment;
    this._userService.getAllStudentDetail().pipe(first()).subscribe((res:any)=>{
      console.log(res);
    });

    this.createstudent();
  }



createstudent(){
  this.addstudentform = new FormGroup({
    stdname:new FormControl('',[Validators.required]), 
    guardian_name:new FormControl('',[Validators.required]),
    bloodgroup:new FormControl('',[Validators.required]),
    phone:new FormControl('',[Validators.required]),
    address:new FormControl('',[Validators.required]),
    state:new FormControl('',[Validators.required]),
    country:new FormControl('',[Validators.required]),
    class:new FormControl('',[Validators.required]),
    group:new FormControl('',[Validators.required]),
    registerno:new FormControl('',[Validators.required]),
    stdroll:new FormControl('',[Validators.required]),
    ex_cur_active:new FormControl('',[Validators.required]),
    remarks:new FormControl('',[Validators.required]),
    section:new FormControl('',[Validators.required]),
    dob:new FormControl('',[Validators.required]), 
    gender:new FormControl('',[Validators.required]), 
    religion:new FormControl('',[Validators.required]), 
    email:new FormControl('',[Validators.required]), 
    username:new FormControl('',[Validators.required]), 
    password:new FormControl('',[Validators.required]), 
  });
}






  addstudentlist(){
    // this._userService.uploadImg().pipe(first()).subscribe((res)=>{
    //   console.log(res);
    // });

    this.dateofbirth= moment(this.addstudentform.value.dob).format('DD-MM-YYYY');
    console.log(this.dateofbirth);
        this._userService.AddStudent(
          this.addstudentform.value.stdname,this.addstudentform.value.guardian_name,
          this.dateofbirth, this.addstudentform.value.bloodgroup,
          this.addstudentform.value.gender, this.addstudentform.value.religion,
          this.addstudentform.value.email, this.addstudentform.value.phone,
          this.addstudentform.value.address,this.addstudentform.value.state,
          this.addstudentform.value.country,this.addstudentform.value.class,
          this.addstudentform.value.section,this.addstudentform.value.group,
          this.addstudentform.value.registerno,
          this.addstudentform.value.stdroll,this.studentpic,
          this.addstudentform.value.ex_cur_active,this.addstudentform.value.remarks,
          this.addstudentform.value.username,this.addstudentform.value.password
          ).pipe(first()).subscribe((res:any)=>{
           console.log(res);
          this.router.navigate(['/adminstudent']);
        });
  }

  updatestudent(data){
    this.dateofbirth= moment(this.addstudentform.value.dateofbirth).format('DD-MM-YYYY');
    console.log(data);
    this.studentid = data ;
    console.log(this.dateofbirth);
     this._userService.UpdateStudent(
       this.studentid,
       this.stdname,
       this.selectedguardianname,
       this.dob,
       this.selectbloodgroup,
      this.selectgender,
       this.selectreligion,
      this.email,
       this.phone,
      this.address,
      this.state,
      this.selectcountry,
      this.selectclass,
      this.selectsection,
      this.selectgroup,
      this.registerno,
      this.stdroll,
      this.photo,
      this.extra_curricular_activities,
      this.remarks,
      this.username,
      this.password
      ).pipe(first()).subscribe((res:any)=>{
    console.log(res);
    this.router.navigate(['/adminstudent']);
     });
  }





  imageupload(file: FileList) {
    this.fileupload =file.item(0);
    console.log(this.fileupload);
    this._userService.uploadImg(this.fileupload).pipe(first()).subscribe((res)=>{
      console.log(res);
      this.studentprofile = res;
      this.studentpic.push(this.studentprofile.file);
      console.log(this.studentpic);
    });

    // this.userdetail = JSON.parse(localStorage.getItem("logininfo"));
    // this._userService.AddStudentProfile(this.file,this.userdetail.id).pipe(first()).subscribe((res:any)=>{
    //   console.log(res);
    // });
}



}
