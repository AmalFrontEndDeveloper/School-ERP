import { Router } from '@angular/router';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { environment} from '../../../environments/environment'
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {
  displayedColumns: string[] = ['photo','name','email','status','action'];
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  environment: any;

  userdetail: any;
  userfulldetail: any;
  constructor(public router:Router,
   public userservice:UserService 
    ) { }
  ngOnInit() {
    this.environment=environment;
    this.userservice.UserDetail().pipe(first()).subscribe((res:any)=>{
      console.log(res);
      this.userdetail = res ;
      this.userfulldetail =  new MatTableDataSource (this.userdetail);
      console.log(this.userfulldetail);
      this.userfulldetail.paginator = this.paginator;
      this.userfulldetail.sort = this.sort;
    });
  }
  adduser(){
   this.router.navigate(['/adduser']);
  }
}
