import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/user.service';
import { first } from 'rxjs/operators';
import { FormGroup, FormControl, Validators, FormBuilder, ValidatorFn, AbstractControl } from '@angular/forms';
export interface Gender {
  genderInfo: string;
}
export interface Religion {
  religion: string;
}
@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.scss']
})
export class AdduserComponent implements OnInit {
  adduserForm:FormGroup
  username:any;
  dateofbirth:any;
  selectgender: any;
  selectreligion: any;
  gender: Gender[] = [
    { genderInfo: 'Male'},
    { genderInfo: 'Female'},
  ];
  religion: Religion[] = [
    { religion: 'Hindu'},
    { religion: 'Christian'},
    { religion: 'Musliam'}
  ];
  constructor(public router:Router,
    public userService : UserService
    ) { }
  ngOnInit() {
    this.createUser();
  }
  adduserlist(){
    this.userService.AddUserAPI(this.username,this.username,this.username,this.username,this.username,this.username,this.username,this.username,this.username,this.username,this.username,this.username).pipe(first()).subscribe((res:any)=>{
      console.log(res);
    });
   this.router.navigate(['/user']);
  }

createUser(){
  this.adduserForm = new FormGroup({
    uname: new FormControl('',[Validators.required]),
    dateofbirth: new FormControl('',[Validators.required]),
    gender: new FormControl('',[Validators.required]),
    religion: new FormControl('',[Validators.required]),
    email: new FormControl('',[Validators.required]),
    phone: new FormControl('',[Validators.required]),
    address: new FormControl('',[Validators.required]),
    join_date: new FormControl('',[Validators.required]),
    photo: new FormControl('',[Validators.required]),
    role: new FormControl('',[Validators.required]),
    username: new FormControl('',[Validators.required]),
    password: new FormControl('',[Validators.required])
  })
}


}
