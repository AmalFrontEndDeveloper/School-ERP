import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarkdistributionComponent } from './markdistribution.component';

describe('MarkdistributionComponent', () => {
  let component: MarkdistributionComponent;
  let fixture: ComponentFixture<MarkdistributionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarkdistributionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarkdistributionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
