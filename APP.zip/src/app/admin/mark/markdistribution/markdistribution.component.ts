import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-markdistribution',
  templateUrl: './markdistribution.component.html',
  styleUrls: ['./markdistribution.component.scss']
})
export class MarkdistributionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
