import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  public route: any;
  pagetitle: string;

  
  constructor(public router: Router ,public location:Location){
    router.events.subscribe((val) => {
      this.route = location.path();
    //  console.log(this.route);
    if(this.route=="/adminstudent"){
      this.pagetitle = "Student"
    }
    if(this.route=="/admindashboard"){
      this.pagetitle = "Dashboard"
    }
    
    if(this.route=="/inbox"){
      this.pagetitle = "Inbox"
    }
    if(this.route=="/activities"){
      this.pagetitle = "Activities"
    }
    if(this.route=="/companies"){
      this.pagetitle = "Companies"
    }
    if(this.route=="/lists"){
      this.pagetitle = "Lists"
    }
    if(this.route=="/joborders"){
      this.pagetitle = "Job Orders"
    }
    if(this.route=="/candidate"){
      this.pagetitle = "Candidate"
    }
    if(this.route=="/myprofile"){
      this.pagetitle = "My Profile"
    }
    if(this.route=="/jobdetail"){
      this.pagetitle = "Job detail"
    }
    if(this.route=="/newevent"){
      this.pagetitle = "New Event"
    }
    if(this.route=="/newcontact"){
      this.pagetitle = "New Contact"
    }
  });
  }

  
}
