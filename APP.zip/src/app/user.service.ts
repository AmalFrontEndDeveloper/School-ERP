import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpHeaders, HttpParams, HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }
  loginuser(username){
    return this.http.post(`${environment.apiUrl}loginuser`,{username:username});
  }
  // loginuser(username,password){
  //   return this.http.post(`${environment.apiUrl}signup`,{username:username,password:password});
  // }
  getAllStudentDetail(){
    return this.http.get(`${environment.apiUrl}student`,{});
  }
  AddStudent(name,guardianname,dob,bloodgroup,gender,religion,email,phone,address,state,country,studentclass,section,stdgroup,registerno,roll,photo,extra_curricular_activities,remarks,username,password){
    return this.http.post(`${environment.apiUrl}student`,{name:name,guardianname:guardianname,dob:dob,bloodgroup:bloodgroup,gender:gender,religion:religion,email:email,phone:phone,address:address,state:state,country:country,studentclass:studentclass,section:section,stdgroup:stdgroup,registerno:registerno,roll:roll,photo:photo,extra_curricular_activities:extra_curricular_activities,remarks:remarks,username:username,password:password});
  }
  DeleteStudent(id){
    return this.http.post(`${environment.apiUrl}Deletestudent`,{id:id});
  }
  UpdateStudent(id,name,guardianname,dob,bloodgroup,gender,religion,email,phone,address,state,country,studentclass,section,stdgroup,registerno,roll,photo,extra_curricular_activities,remarks,username,password){
    return this.http.post(`${environment.apiUrl}Update_student/${id}`,{name:name,guardianname:guardianname,dob:dob,bloodgroup:bloodgroup,gender:gender,religion:religion,email:email,phone:phone,address:address,state:state,country:country,studentclass:studentclass,section:section,stdgroup:stdgroup,registerno:registerno,roll:roll,photo:photo,extra_curricular_activities:extra_curricular_activities,remarks:remarks,username:username,password:password});
  }

AddTeacherAPI(teacher_name,designation,date_of_birth,gender,religion,email,phone,address,joining_date,photo,username,password){
  return this.http.post(`${environment.apiUrl}teacherCreate`,{teacher_name:teacher_name,designation:designation,date_of_birth:date_of_birth,gender:gender,religion:religion,email:email,phone:phone,address:address,joining_date:joining_date,photo:photo,username:username,password:password});
}
UserDetail(){
  return this.http.get(`${environment.apiUrl}user`,{});
}
AddUserAPI(name,date_of_birth,gender,religion,email,phone,address,joining_date,photo,role,username,password){
  return this.http.post(`${environment.apiUrl}user`,{name:name,date_of_birth:date_of_birth,gender:gender,religion:religion,email:email,phone:phone,address:address,joining_date:joining_date,photo:photo,role:role,username:username,password:password});
}

AddStudentProfile(file: File,userid){
  const endpoint = environment.apiUrl+'upload';
  const formData: FormData = new FormData();
  formData.append('file', file);
  formData.append('userid', userid);
  return this.http.post(endpoint, formData);
  // return this.http.post(`${environment.apiUrl}upload`,{name:name,type:type,size:size});
}

uploadImg(file:File){
  const endpoint = environment.apiUrl+'upload';
  const formData: FormData = new FormData();
  formData.append('file', file);
  // formData.append('userid', userid);
  return this.http.post(endpoint, formData);
  // return this.http.post(`${environment.apiUrl}upload`,{});
}
ParentsuploadImg(file:File){
  const endpoint = environment.apiUrl+'parentupload';
  const formData: FormData = new FormData();
  formData.append('file', file);
  // formData.append('userid', userid);
  return this.http.post(endpoint, formData);
}

StudentCount(){
return this.http.get(`${environment.apiUrl}stundentCount`,{});
}
ParentsCount(){
  return this.http.get(`${environment.apiUrl}parentsCount`,{});
}
teacherCount(){
    return this.http.get(`${environment.apiUrl}teacherCount`,{});
}



// Parent Details  Here 
parentsDetails(){
  return this.http.post(`${environment.apiUrl}parents`,{});
}
CreateParent(guardian_name,father_name,mother_name,father_profession,mother_profession,email,phone,address,photo,username,password){
  return this.http.post(`${environment.apiUrl}Createparents`,{guardian_name:guardian_name,father_name:father_name,mother_name:mother_name,father_profession:father_profession,mother_profession:mother_profession,email:email,phone:phone,address:address,photo:photo,username:username,password:password});
}
DeleteParent(id){
  return this.http.post(`${environment.apiUrl}Deleteparents`,{id:id})
}

// Section Details Here 
sectionInfo(){
  return this.http.post(`${environment.apiUrl}section`,{});
}
AddSection(section,category,capacity,class_id,teacher_id,note){
  return this.http.post(`${environment.apiUrl}add_section`,{section:section,category:category,capacity:capacity,class_id:class_id,teacher_id:teacher_id,note:note});
}
Teachernames(){
return this.http.post(`${environment.apiUrl}teacherNames`,{});
}
TeacherDetail(){
  return this.http.post(`${environment.apiUrl}teacher`,{});
}
TeacherDelete(id){
  return this.http.post(`${environment.apiUrl}teacherDelete`,{id:id});
}
TeacherUpdate(teacher_id,teacher_name,designation,date_of_birth,gender,religion,email,phone,address,joining_date,photo,username,password){
  return this.http.post(`${environment.apiUrl}teacherUpdate`,{teacher_id:teacher_id,teacher_name:teacher_name,designation:designation,date_of_birth:date_of_birth,gender:gender,religion:religion,email:email,phone:phone,address:address,joining_date:joining_date,photo:photo,username:username,password:password});
}

// Class Code start Here
ClassNames(){
  return this.http.post(`${environment.apiUrl}classNames`,{});
}
sectionNames(sectionid){
  return this.http.post(`${environment.apiUrl}sectionNames`,{sectionid:sectionid});
}
SubjectNames(id){
  return this.http.post(`${environment.apiUrl}Singlesubject`,{id:id});
}

MailSms(to_phone,textmessage){
  return this.http.post(`${environment.apiUrl}sms_send`,{to_phone:to_phone,textmessage:textmessage});
}
OtherSmsDetail(){
  return this.http.post(`${environment.apiUrl}othersms_send_detail`,{});
}
OtherSms(name,to_phone,sendby,textmsg){
  return this.http.post(`${environment.apiUrl}othersms_send`,{name:name,to_phone:to_phone,sendby:sendby,textmsg:textmsg});
}

  getPCAPlot(callback: (data: any) => void) {
    const url = `assets/json/test.json`;
    this.http.get(url).subscribe(
      // this.http.get(this.appConfig.getConfig('listUser')).subscribe(
      data => {
        callback(data);
      }, error => {
        callback([]);
      });

    //   const headers = new HttpHeaders({
    //     'Content-Type': 'application/json',
    //     Authorization: `Token ${auth_token}`,
    //   });
    //   this.http.get(`${this.env.apiUrl}${this.appConfig.getConfig('pca')}`, {
    //     headers: headers
    //   }).subscribe(
    //     data => {
    //       console.log("=================getUserManagement ==========>", data);
    //       callback(data);
    //     });
    // }
  }


}
