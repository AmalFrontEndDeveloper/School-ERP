import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { UserService } from '../user.service';
// import { first } from 'rxjs/operators';


export interface Role {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  role: Role[] = [
    {value: 'admin', viewValue: 'Admin'},
    {value: 'teacher', viewValue: 'Teacher'},
    {value: 'student', viewValue: 'Student'},
    {value: 'user', viewValue: 'User'},
  ];

  public  loginbg="loginbg.jpg"
  username: any;
  hide = true;
  password: string;
  emailid: any;
  pass: any;
  constructor(public router:Router,public userservice:UserService) { }
  ngOnInit() {
  }
  registerClick(){
  this.router.navigate(['/register']);
  }
  LoginClick(){
    console.log(this.username)
    console.log(this.pass)
           this.userservice.loginuser(this.username).pipe(first()).subscribe((res:any)=>{
           console.log(res);
           localStorage.setItem('logininfo',JSON.stringify(res));
           this.router.navigate(['/admindashboard']);
  });
  this.router.navigate(['/admindashboard']);
}
}
