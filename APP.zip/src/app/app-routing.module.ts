import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashoardComponent } from './admin/dashoard/dashoard.component';
import { StudentComponent } from './admin/student/student.component';
import { TeacherComponent } from './admin/teacher/teacher.component';
import { UserComponent } from './admin/user/user.component';
import { AddstudentComponent } from './admin/student/addstudent/addstudent.component';
import { ParentsComponent } from './admin/parents/parents.component';
import { AddparentsComponent } from './admin/parents/addparents/addparents.component';
import { AdduserComponent } from './admin/user/adduser/adduser.component';
import { AddteacherComponent } from './admin/teacher/addteacher/addteacher.component';
import { ClassComponent } from './academic/class/class.component';
import { AssignmentComponent } from './academic/assignment/assignment.component';
import { RountineComponent } from './academic/rountine/rountine.component';
import { SectionComponent } from './academic/section/section.component';
import { SubjectComponent } from './academic/subject/subject.component';
import { SyllabusComponent } from './academic/syllabus/syllabus.component';
import { AddclassComponent } from './academic/class/addclass/addclass.component';
import { AddsectionComponent } from './academic/section/addsection/addsection.component';
import { AddsubjectComponent } from './academic/subject/addsubject/addsubject.component';
import { AddsyllabusComponent } from './academic/syllabus/addsyllabus/addsyllabus.component';
import { AddassignmentComponent } from './academic/assignment/addassignment/addassignment.component';
import { AddrountineComponent } from './academic/rountine/addrountine/addrountine.component';
import { StudentattendanceComponent } from './admin/attendance/studentattendance/studentattendance.component';
import { TeacherattendanceComponent } from './admin/attendance/teacherattendance/teacherattendance.component';
import { UserattendanceComponent } from './admin/attendance/userattendance/userattendance.component';
import { AddstudentattendanceComponent } from './admin/attendance/studentattendance/addstudentattendance/addstudentattendance.component';
import { AddmailsmsComponent } from './admin/mailsms/addmailsms/addmailsms.component';
import { MailsmsComponent } from './admin/mailsms/mailsms.component';
import { SchedulerComponent } from './admin/scheduler/scheduler.component';

const routes: Routes = [
  { path:'',component:LoginComponent},
  { path:'login',component:LoginComponent},
  { path:'admindashboard',component:DashoardComponent},
  { path:'adminstudent',component:StudentComponent},
  { path:'teacher',component:TeacherComponent},
  { path:'addteacher',component:AddteacherComponent},
  { path:'user',component:UserComponent},
  { path:'scheduler',component:SchedulerComponent},
  { path:'adduser',component:AdduserComponent},
  { path:'addstudent',component:AddstudentComponent},
  { path:'parents',component:ParentsComponent},
  { path:'addparents',component:AddparentsComponent},
  { path:'class',component:ClassComponent},
  { path:'assignment',component:AssignmentComponent},
  { path:'addassignment',component:AddassignmentComponent},
  { path:'rountine',component:RountineComponent},
  { path:'addrountine',component:AddrountineComponent},
  { path:'section',component:SectionComponent},
  { path:'subject',component:SubjectComponent},
  { path:'addsubject',component:AddsubjectComponent},
  { path:'syllabus',component:SyllabusComponent},
  { path:'addsyllabus',component:AddsyllabusComponent},
  { path:'addclass',component:AddclassComponent},
  { path:'addsection',component:AddsectionComponent},
  { path:'student_attendace',component:StudentattendanceComponent},
  { path:'addstudent_attendace',component:AddstudentattendanceComponent},
  { path:'teacher_attendace',component:TeacherattendanceComponent},
  { path:'user_attendace',component:UserattendanceComponent},
  { path:'addmailsms',component:AddmailsmsComponent},
  { path:'mailsms',component:MailsmsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
