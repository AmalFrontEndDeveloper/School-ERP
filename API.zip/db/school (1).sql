-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 23, 2019 at 03:19 PM
-- Server version: 10.1.39-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `class_id` int(11) NOT NULL,
  `class_type` text NOT NULL,
  `class_numeric` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `notes` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_id`, `class_type`, `class_numeric`, `teacher_id`, `notes`) VALUES
(1, 'Two', 2, 2, 'This Secondstandard'),
(2, 'One', 1, 3, 'This Secondstandard');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `EmpID` int(11) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `EmpCode` varchar(50) DEFAULT NULL,
  `Salary` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`EmpID`, `Name`, `EmpCode`, `Salary`) VALUES
(10, 'Amal', 'Empl33', 20000),
(11, 'Amal', 'Empl33', 20000),
(12, '123456', 'Emp19', 39999),
(20, 'Sam', 'Emp19', 21000),
(21, 'Sam', 'Emp19', 21000),
(25, 'Sam', 'Emp19', 21000),
(40, 'AS', 'ASDDD', 455565),
(47, 'Dev', 'Emp19', 55000),
(122, 'ASD AR', 'ASDDD', 455565),
(402, 'ASD AR', 'ASDDD', 455565),
(403, 'Amal', 'DOTSIT', 21000),
(404, 'Amal', 'DOTSIT', 21000),
(405, 'Amal', 'DOTSIT', 21000),
(406, 'Amal', 'DOTSIT', 21000),
(407, 'Amdal', 'dDOTSIT', 210);

-- --------------------------------------------------------

--
-- Table structure for table `file`
--

CREATE TABLE `file` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `type` varchar(100) NOT NULL,
  `size` int(11) NOT NULL,
  `updated_by` varchar(255) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mailsms`
--

CREATE TABLE `mailsms` (
  `id` int(11) NOT NULL,
  `role` int(11) NOT NULL,
  `schoolyear` text NOT NULL,
  `users` text NOT NULL,
  `subject` text NOT NULL,
  `template` text NOT NULL,
  `sendby` text NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `othersms`
--

CREATE TABLE `othersms` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `phone` text NOT NULL,
  `sendby` text NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `othersms`
--

INSERT INTO `othersms` (`id`, `name`, `phone`, `sendby`, `message`) VALUES
(1, 'Amal', '2147483647', 'Amal', 'Your Son Today Absent'),
(2, 'AmalAR', '2147483647', 'AmalAR', 'Hey'),
(3, 'Honest', '7418129254', 'Vimal', 'Hi Baby');

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `parentsid` int(11) NOT NULL,
  `guardian_name` varchar(50) NOT NULL,
  `father_name` varchar(50) NOT NULL,
  `mother_name` varchar(50) NOT NULL,
  `father_profession` varchar(50) NOT NULL,
  `mother_profession` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(150) NOT NULL,
  `photo` varchar(150) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parents`
--

INSERT INTO `parents` (`parentsid`, `guardian_name`, `father_name`, `mother_name`, `father_profession`, `mother_profession`, `email`, `phone`, `address`, `photo`, `username`, `password`) VALUES
(11, 'Vani', 'Muthu', 'Vani', 'Farmer', 'House Wife', 'vaniammu@gmail.com', '7418129256', 'Coimbatore', 'uploads/file-1565771590063.jpg', 'vaniv', 'vani'),
(12, 'Amal', 'Rajkumar', 'Susai Mary', 'Farmer', 'House Wife', 'amal@gmail.com', '7418129254', 'T.v.malai', 'uploads/file-1566391710307.png', 'Amal', 'amal@143');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `subcat_id` int(11) NOT NULL,
  `description` int(255) NOT NULL,
  `Image` int(255) NOT NULL,
  `subImage` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `offer_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `section_id` int(11) NOT NULL,
  `section` text NOT NULL,
  `category` text NOT NULL,
  `capacity` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`section_id`, `section`, `category`, `capacity`, `class_id`, `teacher_id`, `note`) VALUES
(1, 'One', 'Best', 30, 1, 1, 'This is B Section'),
(2, 'gh', 'uh', 0, 0, 0, 'u'),
(3, 'gh', 'uh', 0, 0, 0, 'u');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `guardianname` text NOT NULL,
  `dob` text NOT NULL,
  `gender` varchar(15) NOT NULL,
  `bloodgroup` varchar(20) NOT NULL,
  `religion` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` varchar(250) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `studentclass` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `stdgroup` varchar(50) NOT NULL,
  `registerno` varchar(50) NOT NULL,
  `roll` varchar(50) NOT NULL,
  `photo` varchar(150) NOT NULL,
  `extra_curricular_activities` varchar(50) NOT NULL,
  `remarks` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `guardianname`, `dob`, `gender`, `bloodgroup`, `religion`, `email`, `phone`, `address`, `state`, `country`, `studentclass`, `section`, `stdgroup`, `registerno`, `roll`, `photo`, `extra_curricular_activities`, `remarks`, `username`, `password`) VALUES
(45, 'Arul', 'Selvi', '22-08-2019', 'Male', 'B+', 'Hindu', 'arul@gmail.com', '7418129254', 'T.v.malai', 'Tamilnadu', 'id1', 'Four', 'section2', 'Arts', '1744265', '', 'uploads/file-1566391494576.jpg', 'Sports', 'Good Boy', 'Arul', 'Arul'),
(46, 'Vani', 'Raj', '23-08-2019', 'Female', 'B-', 'Hindu', 'vani@gmail.com', '7418129254', 'Chennai', 'Tamilnadu', 'id1', 'Five', 'section3', 'Arts', '1744264', '', 'uploads/file-1566391615588.jpg', 'Sports', 'Good Girl', 'Vani', 'vaniammu');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacher_id` int(11) NOT NULL,
  `teacher_name` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `date_of_birth` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `religion` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `joining_date` varchar(50) NOT NULL,
  `photo` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacher_id`, `teacher_name`, `designation`, `date_of_birth`, `gender`, `religion`, `email`, `phone`, `address`, `joining_date`, `photo`, `username`, `password`) VALUES
(1, 'Amal', 'Softwaredeveloper', '1995-02-08T18:30:00.000Z', 'Male', 'Christan', 'amal@gmail.com', '7418129254', 'Chennai', '2019-08-29T18:30:00.000Z', 'uploads/file-1566482142323.png', 'Amal', 'Amal');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date_of_birth` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `religion` varchar(20) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(250) NOT NULL,
  `joining_date` varchar(20) NOT NULL,
  `photo` varchar(150) NOT NULL,
  `role` varchar(150) NOT NULL,
  `username` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `name`, `date_of_birth`, `gender`, `religion`, `email`, `phone`, `address`, `joining_date`, `photo`, `role`, `username`, `password`) VALUES
(12344, 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test'),
(12345, 'Amal', '9-02-1995', 'Male', 'Christan', 'amal@gmail.com', '7418129254', 'T.v.malai', '08-08-2018', 'amal.jpg', 'User', 'Amal', 'Amal@143'),
(12346, '12344', 'cc', 'cc', 'cc', 'cc', 'cc', 'cc', 'cc', 'cc', 'cc', 'cc', 'cc'),
(12347, '12344', 'gf', 'gf', 'gf', 'gf', 'gf', 'gf', 'gf', 'gf', 'gf', 'gf', 'gf');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`EmpID`);

--
-- Indexes for table `mailsms`
--
ALTER TABLE `mailsms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `othersms`
--
ALTER TABLE `othersms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`parentsid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`section_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `EmpID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=408;

--
-- AUTO_INCREMENT for table `mailsms`
--
ALTER TABLE `mailsms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `othersms`
--
ALTER TABLE `othersms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `parents`
--
ALTER TABLE `parents`
  MODIFY `parentsid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `section`
--
ALTER TABLE `section`
  MODIFY `section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12348;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
