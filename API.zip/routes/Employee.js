// var express = require('express');
// var router = express.Router();
// var mysqlConnection = require('../database/db.js');
 
//   // ------------------ >> Add  Employee
//   router.post('/',function(req,res){
//     var EmpID = req.body.EmpID;
//     var Name = req.body.Name;
//     var EmpCode = req.body.EmpCode;
//     var Salary = req.body.Salary;
//    var sql  = `INSERT INTO employee (EmpID,Name,EmpCode,Salary) VALUES("${EmpID}", "${Name}", "${EmpCode}","${Salary}")`;
//     // var sql  = "INSERT INTO `employee` (EmpID,Name,EmpCode,Salary) VALUES ('11','Amal','Empl33','20000')";
//     mysqlConnection.query(sql,function(err,result){
//         console.log(result)
//         if(!err)
//         res.send(result);
//         // result.forEach(element => {
//         //     if(element.constructor == Array)
//         //     res.send("Inserted Student ID :" +element[0].EmpID);
//         // });
//         else
//         console.log(err);
//     })
//   });

// // ------------------ >> Update  Employee
// router.put('/:id',function(req,res){
//     var EmpID = req.body.EmpID;
//     var Name = req.body.Name;
//     var EmpCode = req.body.EmpCode;
//     var Salary = req.body.Salary;
//    var sql  = `UPDATE employee SET Name="${Name}",EmpCode="${EmpCode}",Salary="${Salary}" WHERE EmpID="${EmpID}"`;
//     mysqlConnection.query(sql,function(err,result){
//         console.log(result)
//         if(!err)
//         res.send(result);
//         else
//         console.log(err);
//     })
//   });


//   module.exports = router ;

