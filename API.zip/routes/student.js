const express = require('express');
const router = express.Router();
// =================================  Student Part Start Here   ==========================
router.get('/',(req,res)=>{
    mysqlConnection.query('SELECT * FROM student',(err,rows,fields)=>{
        if(!err)
        res.send(rows);       
        else
        console.log(err);
    })
});
// ------------------ >> Single Student Detail 
router.get('/:id',(req,res)=>{
  mysqlConnection.query('SELECT * FROM student WHERE id = ? ',[req.params.id],(err,rows,fields)=>{
      if(!err)
      res.send(rows);
      else
      console.log(err);
  })
});
// ------------------ >> Delete Student 
router.delete('/:id',(req,res)=>{
    mysqlConnection.query('DELETE FROM student WHERE id = ? ',[req.params.id],(err,rows,fields)=>{
        if(!err)
        res.send("Deleted Successfully..!");
        else
        console.log(err);
    })
  });

// ------------------ >> Add  Student 
// app.post('/student',(req,res)=>{
//     let std = req.body;
//     var sql = "SET @id = ?;SET @name = ?;SET @gender = ?;SET @bloodgroup = ?;SET @religion = ?;SET @email = ?;SET @phone = ?;SET @address = ?;SET @state = ?;SET @country = ?;SET @class = ?;SET @section = ?;SET @group = ?;SET @registerno = ?;SET @roll = ?;SET @photo = ?;SET @extra_curricular_activities = ?;SET @remarks = ?;SET @username = ?;SET @password = ?; \
//     CALL student(@id,@name,@gender,@bloodgroup,@religion,@email,@phone,@address,@state,@country,@class,@section,@group,@registerno,@roll,@photo,@extra_curricular_activities,@remarks,@username,@password);";
//     mysqlConnection.query(sql,[std.id,std.name,std.gender,std.bloodgroup,std.religion,std.email,std.phone,std.address,std.state,std.country,std.class,std.section,std.group,std.registerno,std.roll,std.photo,std.extra_curricular_activities,std.remarks,std.username,std.password],(err,rows,fields)=>{
//         if(!err)
//         // res.send(rows);
//         rows.forEach(element => {
//             if(element.constructor == Array)
//             res.send("Inserted Student ID :" +element[0].id);
//         });
//         else
//         console.log(err);
//     })
//   });


router.post('/',(req,res)=>{
    var stdid = req.body.id;
    var stdname = req.body.name;
    var stdgender= req.body.gender;
    var stdbloodgroup = req.body.bloodgroup;
    var stdreligion = req.body.religion;
    var stdemail = req.body.email;
    var stdphone = req.body.phone;
    var stdaddress = req.body.address;
    var stdstate = req.body.state;
    var stdcountry = req.body.country;
    var stdclass = req.body.class;
    var stdsection = req.body.section;
    var stdgroup = req.body.group;
    var stdregisterno = req.body.registerno;
    var stdphoto = req.body.photo;
    var stdextra_curricular_activities = req.body.extra_curricular_activities;
    var stdremarks = req.body.remarks;
    var stdusername = req.body.username;
    var stdpassword = req.body.password;
   
    var sql = `INSERT INTO student (id, name, gender, bloodgroup, religion, email, phone, address, state, country, class, section, group, registerno, photo, extra_curricular_activities, remarks, username, password) VALUES("${stdid}", "${stdname}", "${stdgender}", "${stdbloodgroup}", "${stdreligion}", "${stdemail}", "${stdphone}", "${stdaddress}", "${stdstate}", "${stdcountry}", "${stdclass}", "${stdsection}", "${stdgroup}", "${stdregisterno}", "${stdphoto}", "${stdextra_curricular_activities}", "${stdremarks}", "${stdusername}", "${stdpassword}")`;
    // mysqlConnection.query(sql,function(err,result){
    //     if(err) throw err;
    // })
   mysqlConnection.query(sql,(err,rows,fields)=>{
    if(!err)
    rows.forEach(element => {
        if(element.constructor == Array)
        res.send("Inserted Student ID :" +element[0].id);
    });
    else
    console.log(err);
   })


});

// ------------------ >> Add  Student 
router.put('/',(req,res)=>{
    let std = req.body;
    var sql = "SET @id = ?;SET @name = ?;SET @gender = ?;SET @bloodgroup = ?;SET @religion = ?;SET @email = ?;SET @phone = ?;SET @address = ?;SET @state = ?;SET @country = ?;SET @class = ?;SET @section = ?;SET @group = ?;SET @registerno = ?;SET @roll = ?;SET @photo = ?;SET @extra_curricular_activities = ?;SET @remarks = ?;SET @username = ?;SET @password = ?; \
    CALL student(@id,@name,@gender,@bloodgroup,@religion,@email,@phone,@address,@state,@country,@class,@section,@group,@registerno,@roll,@photo,@extra_curricular_activities,@remarks,@username,@password);";
    mysqlConnection.query(sql,[std.id,std.name,std.gender,std.bloodgroup,std.religion,std.email,std.phone,std.address,std.state,std.country,std.class,std.section,std.group,std.registerno,std.roll,std.photo,std.extra_curricular_activities,std.remarks,std.username,std.password],(err,rows,fields)=>{
        if(!err)
        res.send(rows);
        // rows.forEach(element => {
        //     if(element.constructor == Array)
        //     res.send("Inserted Student ID :" +element[0]);
        // });
        else
        console.log(err);
    })
  });


 module.exports = router;  