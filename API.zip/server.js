const mysql = require ('mysql');
const express = require('express');
const multer = require('multer');
const path =  require('path');
var morgan = require('morgan');
const socketio = require('socket.io');
var fs = require('fs');
var admin = require("firebase-admin");
// admin.initializeApp(functions.config().firebase);
const twilio = require('twilio');



// const Nexmo = require('nexmo');


// const client =require('twilio')(accountSid, authToken);
const accountSid = 'AC570054862881b132540ab90807fbadbc';
const authToken = '65067d4ee0b7ea1af9d8bd3defaabc43';
const client = new twilio(accountSid,authToken);





// const nexmo = new Nexmo({
//     apiKey: 'aff91eb8',
//     apiSecret: 'a1ZqSZdMLu9DDAuK',
// },
// {debug: true}
// );








var app = express();

app.use(morgan('dev'));
var accessLogStream = fs.createWriteStream(
    path.join(__dirname, 'access.log'), {flags: 'a'}
);
// setup the logger
app.use(morgan('combined', {stream: accessLogStream}));

// const DIR = '.public/uploads/';
const storage = multer.diskStorage({
    destination:'public/uploads/',
    //     destination: function (req, file, callback) {
    //   callback(null, DIR);
    // },
    filename: function (req, file, cb) {
      cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({
    storage: storage,
    limits:{fileSize:1000000},
    fileFilter: function(req, file, cb){
        checkFileType(file, cb);
    }
}).single('file');

function checkFileType(file, cb){
    const filetypes = /jpeg|jpg|png|gif/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);
    if(mimetype && extname){
        return cb(null,true);
    }else{
        cb('Error: Images Only!');
    }
}

app.use('/public/uploads',express.static('public/uploads'));


app.use((req,res,next) =>{
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
    if(req.method === 'OPTIONS'){
        res.header('Access-Control-Allow-Methods', 'PUT, POST, PATCH, DELETE, GET'); //to give access to all the methods provided
        return res.status(200).json({});
    }
    next(); //so that other routes can take over
});

const bodyparser = require('body-parser');
app.use(bodyparser.json());
// app.use(fileUpload());

var mysqlConnection = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database: 'school',
    multipleStatements:true
});
mysqlConnection.connect((err)=>{
    if (!err)
    console.log('DB Connection Successed.');
    else
    console.log('DB Connection failed \n Error : ' + JSON.stringify(err,undefined, 2));
});

app.listen(5000,()=>console.log('Express Server is Running at port no : 5000'));

// var mysqlConnection = require('./database/db.js');
// var Employee = require('./routes/Employee');
// app.use('/employee', Employee);




app.post('/upload',(req,res)=>{
    upload(req,res, (err)=>{
     if(err){
         res.send({ message:err})
     }else{
         console.log(req.file);
if(req.file == undefined){
          res.send({ message:  'No File Selected' });
}else{
    res.send({
         message: 'File Uploaded', 
         file: `uploads/${req.file.filename}`
});
}}
})
});






app.get('/employee',(req,res)=>{
    mysqlConnection.query('SELECT * FROM employee',(err,rows,fields)=>{
        if(!err)
        res.send(rows);
        else
        console.log(err);
    })
  });
app.get('/employee/:id',(req,res)=>{
    mysqlConnection.query('SELECT * FROM employee WHERE EmpID = ? ',[req.params.id],(err,rows,fields)=>{
        if(!err)
        res.send(rows);
        else
        console.log(err);
    })
  });
  app.post('/employee',function(req,res){
    var EmpID = req.body.EmpID;
    var Name = req.body.Name;
    var EmpCode = req.body.EmpCode;
    var Salary = req.body.Salary;
   var sql  = `INSERT INTO employee (EmpID,Name,EmpCode,Salary) VALUES("${EmpID}", "${Name}", "${EmpCode}","${Salary}")`;
    mysqlConnection.query(sql,function(err,result){
        console.log(result)
        if(!err)
        res.status(204).send();     
        else
        console.log(err);
    })
  });

// ------------------ >> Update  Employee
app.put('/employee/:id',function(req,res){
    var EmpID = req.body.EmpID;
    var Name = req.body.Name;
    var EmpCode = req.body.EmpCode;
    var Salary = req.body.Salary;
   var sql  = `UPDATE employee SET Name="${Name}",EmpCode="${EmpCode}",Salary="${Salary}" WHERE EmpID="${EmpID}"`;
    mysqlConnection.query(sql,function(err,result){
        console.log(result)
        if(!err)
        res.send(result);
        else
        console.log(err);
    })
  });

// =================================  Student Part Start Here   ==========================
app.get('/student',(req,res)=>{
    mysqlConnection.query('SELECT * FROM student',(err,rows,fields)=>{
        if(!err)
        res.status(204).send();       
        else
        console.log(err);
    })
});
// ------------------ >> Single Student Detail 
app.get('/student/:id',(req,res)=>{
  mysqlConnection.query('SELECT * FROM student WHERE id = ? ',[req.params.id],(err,rows,fields)=>{
      if(!err)
      res.send([rows]);
      else
      console.log(err);
  })
});
// ------------------ >> StudentCount
app.get('/stundentCount',(req,res)=>{
    mysqlConnection.query('SELECT COUNT(*) AS `StudentCount` FROM  student',(err,rows)=>{
        if(!err)
        res.send({
            message: rows
        });
        else
        console.log(err);
    })
  });
  // ------------------ >> ParentCount
app.get('/parentsCount',(req,res)=>{
    mysqlConnection.query('SELECT COUNT(*) AS `StudentCount` FROM  parents',(err,rows)=>{
        if(!err)
        res.send({
            message: rows
        });
        else
        console.log(err);
    })
  });
  // ------------------ >> TecaherCount
app.get('/teacherCount',(req,res)=>{
    mysqlConnection.query('SELECT COUNT(*) AS `StudentCount` FROM  teacher',(err,rows)=>{
        if(!err)
        res.send({
            message: rows
        });
        else
        console.log(err);
    })
  });
// ------------------ >> Delete Student 
app.post('/',(req,res)=>{
    mysqlConnection.query('DELETE FROM student WHERE id = ? ',[req.params.id],(err,rows,fields)=>{
        if(!err)
        res.send({
            message:'Deleted Successfully..!'
        });
        else
        console.log(err);
    })
  });


  app.post('/parentupload',(req,res)=>{
    upload(req,res, (err)=>{
     if(err){
         res.send({ message:err})
     }else{
         console.log(req.file);
if(req.file == undefined){
          res.send({ message:  'No File Selected' });
}else{
    res.send({
         message: 'File Uploaded', 
         file: `uploads/${req.file.filename}`
});
}}
})
});


// ------------------ >> Add  Student 
app.post('/student',(req,res)=>{
    var name = req.body.name;
    var guardianname = req.body.guardianname;
    var dob = req.body.dob;
    var gender = req.body.gender;
    var bloodgroup = req.body.bloodgroup;
    var religion = req.body.religion;
    var email = req.body.email;
    var phone = req.body.phone;
    var address = req.body.address;
    var state = req.body.state;
    var country = req.body.country;
    var studentclass = req.body.studentclass;
    var section = req.body.section;
    var stdgroup  = req.body.stdgroup;
    var registerno = req.body.registerno;
    var photo = req.body.photo;
    var extra_curricular_activities = req.body.extra_curricular_activities;
    var remarks = req.body.remarks;
    var username = req.body.username;
    var password = req.body.password;
    var sql = `INSERT INTO student (name, guardianname, dob, gender, bloodgroup, religion, email, phone, address, state, country, studentclass, section, stdgroup, registerno, photo, extra_curricular_activities, remarks, username, password) VALUES("${name}","${guardianname}","${dob}", "${gender}", "${bloodgroup}", "${religion}", "${email}", "${phone}", "${address}", "${state}", "${country}", "${studentclass}", "${section}", "${stdgroup}", "${registerno}", "${photo}", "${extra_curricular_activities}", "${remarks}", "${username}", "${password}")`;
    mysqlConnection.query(sql,function(err,result){
    console.log(result)
    if(!err)
    res.send({
      message: 'Student Detail Created',
      Result : result
    });
    else
    res.send({
     message:'Student Detail Not Created',
     result:err   
    });
    console.log(err);
})
});

// ------------------ >> Add  Student 
app.post('/Update_student/:id',(req,res)=>{
    // app.put('/student',(req,res)=>{

    var studentid = req.params.id;
    
    var name = req.body.name;
    var guardianname = req.body.guardianname;
    var dob = req.body.dob;
    var gender = req.body.gender;
    var bloodgroup = req.body.bloodgroup;
    var religion = req.body.religion;
    var email = req.body.email;
    var phone = req.body.phone;
    var address = req.body.address;
    var state = req.body.state;
    var country = req.body.country;
    var studentclass = req.body.studentclass;
    var section = req.body.section;
    var stdgroup  = req.body.stdgroup;
    var roll = req.body.roll;
    var registerno = req.body.registerno;
    var photo = req.body.photo;
    var extra_curricular_activities = req.body.extra_curricular_activities;
    var remarks = req.body.remarks;
    var username = req.body.username;
    var password = req.body.password;

    var sql = `UPDATE student SET name ="${name}",guardianname = "${guardianname}", dob = "${dob}",gender = "${gender}",bloodgroup = "${bloodgroup}", religion = "${religion}", email = "${email}",phone = "${phone}",address = "${address}", state = "${state}",country = "${country}",studentclass = "${studentclass}", section = "${section}",stdgroup = "${stdgroup}",roll = "${roll}",registerno = "${registerno}", photo = "${photo}",extra_curricular_activities = "${extra_curricular_activities}",remarks = "${remarks}", username = "${username}",password = "${password}" WHERE id = "${studentid}"`;
    mysqlConnection.query(sql,(err,result)=>{
        if(!err) res.send({
            message:result,
            response:'Updated Successfully...!'
        });
        else console.log(err);
    })
  });


//   ===================== Parents Code Start Here  ==================
app.post('/parents',(req,res)=>{
mysqlConnection.query('SELECT * FROM parents',(err,result,fields)=>{
if(!err)
res.send(result);
else
console.log(err)
})
});

// ------------------ >> Single Parents Detail 
app.post('/parents/:id',(req,res)=>{
mysqlConnection.query('SELECT * FROM parents WHERE parentsid = ? ', [req.params.id],(err,rows,fields)=>{
    if(!err)
    res.send(rows);
    else
    console.log(err)
})
});
// ------------------ >> Delete Parents Detail 
app.post('/Deleteparents',(req,res)=>{
    mysqlConnection.query('DELETE FROM parents WHERE parentsid = ? ', [req.body.id],(err,rows,fields)=>{
        if(!err)
        res.send({
            message: "Deleted Successfully..!"
        });
        else
        console.log(err)
    })
    });
// ------------------ >> Update Parents  
app.post('/Createparents',(req,res)=>{
    // var parentsid = req.body.parentsid;
    var guardian_name = req.body.guardian_name;
    var father_name = req.body.father_name;
    var mother_name = req.body.mother_name;
    var father_profession = req.body.father_profession;
    var mother_profession = req.body.mother_profession;
    var email = req.body.email;
    var phone = req.body.phone;
    var address = req.body.address;
    var photo = req.body.photo;
    var username = req.body.username;
    var password = req.body.password;
    var sql = `INSERT INTO parents (guardian_name,father_name,mother_name,father_profession,mother_profession,email,phone,address,photo,username,password) 
    VALUES ("${guardian_name}","${father_name}","${mother_name}","${father_profession}","${mother_profession}","${email}","${phone}","${address}","${photo}","${username}","${password}")`;
    mysqlConnection.query(sql,(err,result)=>{
        console.log(result);
        if(!err)
        res.send({
            // Result: 'Parents SuccessFully Created......!',
            status: 1 ,
            message: 'Parents SuccessFully Created......!'
        });
        else
        console(err);
    })
  });
  // ------------------ >> Update Parents  
app.put('/parents/:id',(req,res)=>{
    var parentsid = req.body.parentsid;
    var guardian_name = req.body.guardian_name;
    var father_name = req.body.father_name;
    var mother_name = req.body.mother_name;
    var father_profession = req.body.father_profession;
    var mother_profession = req.body.mother_profession;
    var email = req.body.email;
    var phone = req.body.phone;
    var address = req.body.address;
    var photo = req.body.photo;
    var username = req.body.username;
    var password = req.body.password;
    var sql = `UPDATE parents SET guardian_name = "${guardian_name}",father_name ="${father_name}",mother_name = "${mother_name}",father_profession = "${father_profession}",mother_profession = "${mother_profession}",email = "${email}",phone ="${phone}",address = "${address}",photo = "${photo}",username ="${username}",password = "${password}", WHERE  parentsid = "${parentsid}"`;
    mysqlConnection.query(sql,(err,result)=>{
        console.log(result);
        if(!err)
        res.send(result);
        else
        console(err);
    })
  });
  
//   ===================== Teacher Code Start Here  ==================
app.post('/teacher',(req,res)=>{
    mysqlConnection.query('SELECT * FROM teacher',(err,result,fields)=>{
    if(!err)
    res.send(result);
    else
    console.log(err)
    })
    });
    
    // ------------------ >> Single Teacher Detail 
    app.post('/teacher/:id',(req,res)=>{
    mysqlConnection.query('SELECT * FROM teacher WHERE teacher_id = ? ', [req.params.id],(err,rows,fields)=>{
        if(!err)
        res.send(rows);
        else
        console.log(err)
    })
    });
    // ------------------ >> Delete Teacher Detail 
    app.post('/teacherDelete',(req,res)=>{
        mysqlConnection.query('DELETE FROM teacher WHERE teacher_id = ? ', [req.body.id],(err,rows,fields)=>{
            if(!err)
            res.send({
                message: "Deleted Successfully..!" 
            });
            else
            console.log(err)
        })
        });
    // ------------------ >> Update Teacher  
    app.post('/teacherCreate',(req,res)=>{
        // var teacher_id = req.body.teacher_id;
        var teacher_name = req.body.teacher_name;
        var designation = req.body.designation;
        var date_of_birth = req.body.date_of_birth;
        var gender = req.body.gender;
        var religion = req.body.religion;
        var email = req.body.email;
        var phone = req.body.phone;
        var address = req.body.address;
        var joining_date = req.body.joining_date;
        var photo = req.body.photo;
        var username = req.body.username;
        var password = req.body.password;

        var sql = `INSERT INTO teacher (teacher_name,designation,date_of_birth,gender,religion,email,phone,address,joining_date,photo,username,password) 
        VALUES ("${teacher_name}","${designation}","${date_of_birth}","${gender}","${religion}","${email}","${phone}","${address}","${joining_date}","${photo}","${username}","${password}")`;
        mysqlConnection.query(sql,(err,result)=>{
            console.log(result);
            if(!err)
            res.send({
                status: 1 ,
                message: 'Teacher SuccessFully Created......!'
            });
            else
            console(err);
        })
      });
    // ------------------ >> Update Parents  
    app.post('/teacherUpdate',(req,res)=>{
        var teacher_id = req.body.teacher_id;
        var teacher_name = req.body.teacher_name;
        var designation = req.body.designation;
        var date_of_birth = req.body.date_of_birth;
        var gender = req.body.gender;
        var religion = req.body.religion;
        var email = req.body.email;
        var phone = req.body.phone;
        var address = req.body.address;
        var joining_date = req.body.joining_date;
        var photo = req.body.photo;
        var username = req.body.username;
        var password = req.body.password;
        var sql = `UPDATE teacher SET teacher_name = "${teacher_name}",designation ="${designation}",date_of_birth = "${date_of_birth}",gender = "${gender}",religion = "${religion}",email = "${email}",phone ="${phone}",address = "${address}",joining_date = "${joining_date}",photo = "${photo}",username ="${username}",password = "${password}" WHERE  teacher_id = "${teacher_id}"`;
        mysqlConnection.query(sql,(err,result)=>{
            console.log(result);
            if(!err)
            res.send(result);
            else
            console(err);
        })
      });  


// ============================ User Info Code Start Here     ============================ 
app.get('/user',(req,res)=>{
    mysqlConnection.query('SELECT * FROM user',(err,result,fields)=>{
        if(!err)
        res.send(result);
        else
        console.log(err);
    })
});
app.get('/user/:id',(req,res)=>{
    mysqlConnection.query('SELECT * FROM user WHERE user_id = ?',[req.params.id],(err,result,fields)=>{
        if(!err)
        res.send(result);
        else
        console.log(err);
    })
});
app.delete('/user/:id',(req,res)=>{
    mysqlConnection.query('DELETE  FROM user WHERE user_id = ?',[req.params.id],(err,result,fields)=>{
        if(!err)
        res.send("Deleted Successfully..!");
        else
        console.log(err);
    })
});

app.post('/loginuser',(req,res)=>{
    console.log(req.body.username);
    // mysqlConnection.query('SELECT * FROM user WHERE username = ?',[req.body.username],(err,result,fields)=>{
    //     if(!err)
    //     res.send({
    //         message: result,
    //         Role:'student'
    //     });
    //     else
    //     console.log(err);
    // })
 var user = {
    username:'amal',
    password:''
 }

    return user;
});

message =''
app.post('/user',(req,res)=>{
    var name = req.body.name;
    var date_of_birth  = req.body.date_of_birth;
    var gender = req.body.gender;
    var religion = req.body.religion;
    var email = req.body.email;
    var phone = req.body.phone;
    var address = req.body.address;
    var joining_date = req.body.joining_date;
    var photo = req.body.photo;
    var role = req.body.role;
    var username = req.body.username;
    var password = req.body.password;

         var sql = `INSERT INTO user (name,date_of_birth,gender,religion,email,phone,address,joining_date,photo,role,username,password)
         VALUES("${name}","${date_of_birth}","${gender}","${religion}","${email}","${phone}","${address}","${joining_date}","${photo}","${role}","${username}","${password}")`;
    mysqlConnection.query(sql,(err,result)=>{
     if(!err) res.send({
         message: 'User Data Added SuccessFully.....!'
     });
     else console.log(err);
    }) 
});
app.post('/user/:id',(req,res)=>{
// app.put('/user/:id',(req,res)=>{
    var user_id = req.params.id;

    var name = req.body.name;
    var date_of_birth  = req.body.date_of_birth;
    var gender = req.body.gender;
    var religion = req.body.religion;
    var email = req.body.email;
    var phone = req.body.phone;
    var address = req.body.address;
    var joining_date = req.body.joining_date;
    var photo = req.body.photo;
    var role = req.body.role;
    var username = req.body.username;
    var password = req.body.password;
var sql = `UPDATE user SET name = "${name}",date_of_birth = "${date_of_birth}",gender = "${gender}",religion = "${religion}",email = "${email}",phone ="${phone}",address = "${address}",joining_date = "${joining_date}",photo = "${photo}",role = "${role}",username = "${username}",password = "${password}" WHERE user_id ="${user_id}" `;
  mysqlConnection.query(sql,(err,result)=>{
     if(!err) res.send(result);
     else console.log(err);
    }) 
});

// -=============================== Acadamic Info  ==============================
// Class Info 
app.post('/class',(req,res)=>{
    mysqlConnection.query('SELECT * FROM class',(err,result,fields)=>{
        if(!err) res.send(result);
        else console.log(err)
    })
});
app.post('/class_single',(req,res)=>{
    mysqlConnection.query('SELECT * FROM class WHERE class_id = ?',[req.body.id],(err,result,fields)=>{
        if(!err) res.send(result);
        else console.log(err)
    })
});
app.post('/classdelete',(req,res)=>{
    mysqlConnection.query('DELETE FROM class WHERE class_id = ?',[req.body.id],(err,result,fields)=>{
        if(!err) res.send("Deleted Successfully..!");
        else console.log(err)
    })
});
app.post('/classAdd',(req,res)=>{
// var class_id = req.body.class_id;
var class_type = req.body.class_type;
var class_numeric = req.body.class_numeric;
var teacher_id = req.body.teacher_id;
var notes = req.body.notes;
var sql = `INSERT INTO class (class_type,class_numeric,teacher_id,notes) VALUES ("${class_type}","${class_numeric}","${teacher_id}","${notes}")`
mysqlConnection.query(sql,(err,result)=>{
    if(!err) res.send({
        message:'Class Created SuccessFully.....!',
        Result:result
    });
    else console.log(err);
})
});

app.post('/classUpdate',(req,res)=>{
    // var class_id = req.body.class_id;
    var class_type = req.body.class_type;
    var class_numeric = req.body.class_numeric;
    var teacher_id = req.body.teacher_id;
    var notes = req.body.notes;
    var sql = `UPDATE class SET class_type ="${class_type}",class_numeric = "${class_numeric}",teacher_id = "${teacher_id}",notes = "${notes}" WHERE class_id = "${class_id}"`;
    mysqlConnection.query(sql,(err,result)=>{
        if(!err) res.send(result);
        else console.log(err);
    })
});
app.post('/classNames',(req,res)=>{
    mysqlConnection.query('SELECT class_id,class_type FROM class',(err,result,fields)=>{
        if(!err) res.send({
            message:result
        });
        else console.log(err)
    })
});



 //   Section Info 
 app.post('/section',(req,res)=>{
     var sectionquery = 'SELECT section.teacher_id,section.section,section.category,section.capacity,section.class_id,section.note,teacher.teacher_name FROM section LEFT JOIN teacher on section.teacher_id = teacher.teacher_id';
    //  var sectionquery = 'SELECT * FROM section';
    mysqlConnection.query(sectionquery,(err,result,fields)=>{
        if(!err) res.send(result);
        else console.log(err)
    })
});
app.post('/section_detail',(req,res)=>{
    mysqlConnection.query('SELECT * FROM section WHERE section_id = ?',[req.body.id],(err,result,fields)=>{
        if(!err) res.send(result);
        else console.log(err)
    })
});
app.post('/sectionNames',(req,res)=>{
    mysqlConnection.query('SELECT * from section WHERE class_id= ?',[req.body.sectionid],(err,result,fields)=>{
        if(!err) res.send(result);
        else console.log(err)
    })
});

app.post('/section_delete',(req,res)=>{
    mysqlConnection.query('DELETE FROM section WHERE section_id = ?',[req.body.id],(err,result,fields)=>{
        if(!err) res.send(" Deleted Successfully..! ");
        else console.log(err)
    })
});
app.post('/add_section',(req,res)=>{
// var section_id = req.body.section_id;
var section = req.body.section;
var category = req.body.category;
var capacity = req.body.capacity;
var class_id = req.body.class_id;
var teacher_id = req.body.teacher_id;
var note = req.body.note;
var sql = `INSERT INTO section (section,category,capacity,class_id,teacher_id,note) VALUES ("${section}","${category}","${capacity}","${class_id}","${teacher_id}","${note}")`
mysqlConnection.query(sql,(err,result)=>{
    if(!err) res.send({
        message:'Section Created Successfully.....!',
        Result: result
    });
    else console.log(err);
})
});

app.put('/student_section/:id',(req,res)=>{
    var section_id = req.body.section_id;
    var section = req.body.section;
    var category = req.body.category;
    var capacity = req.body.capacity;
    var class_id = req.body.class_id;
    var teacher_id = req.body.teacher_id;
    var note = req.body.note;
    var sql = `UPDATE section SET section ="${section}",category = "${category}",capacity = "${capacity}",class_id = "${class_id}",teacher_id = "${teacher_id}",note = "${note}" WHERE section_id = "${section_id}"`;
    mysqlConnection.query(sql,(err,result)=>{
        if(!err) res.send(result);
        else console.log(err);
    })
});         
app.post('/teacherNames',(req,res)=>{
    var sectionquery = 'SELECT teacher_id,teacher_name FROM teacher';
   //  var sectionquery = 'SELECT * FROM section';
   mysqlConnection.query(sectionquery,(err,result,fields)=>{
       if(!err) res.json({
           data:result
       });
       else console.log(err)
   })
});


     //   Subject Info 
 app.get('/subject',(req,res)=>{
    mysqlConnection.query('SELECT * FROM subject',(err,result,fields)=>{
        if(!err) res.send(result);
        else console.log(err)
    })
});
app.post('/Singlesubject',(req,res)=>{
    mysqlConnection.query('SELECT * FROM subject WHERE section_id = ?',[req.body.id],(err,result,fields)=>{
        if(!err) res.send(result);
        else console.log(err)
    })
});
app.delete('/subject/:id',(req,res)=>{
    mysqlConnection.query('DELETE FROM subject WHERE section_id = ?',[req.params.id],(err,result,fields)=>{
        if(!err) res.send(" Deleted Successfully..! ");
        else console.log(err)
    })
});
app.post('/subject',(req,res)=>{
var subject_id = req.body.subject_id;
var class_name = req.body.class_name;
var teacher_name = req.body.teacher_name;
var type = req.body.type;
var passmark = req.body.passmark;
var finalmark = req.body.finalmark;
var subjectname = req.body.subjectname;
var subject_author = req.body.subject_author;
var subject_code = req.body.subject_code;
var sql = `INSERT INTO subject (subject_id,class_name,teacher_name,type,passmark,finalmark,subjectname,subject_author,subject_code) VALUES ("${subject_id}","${class_name}","${teacher_name}","${type}","${passmark}","${finalmark}","${subjectname}","${subject_author}","${subject_code}")`;
mysqlConnection.query(sql,(err,result)=>{
    if(!err) res.send(result);
    else console.log(err);
})
});
app.put('/subject/:id',(req,res)=>{
    var subject_id = req.body.subject_id;
    var class_name = req.body.class_name;
    var teacher_name = req.body.teacher_name;
    var type = req.body.type;
    var passmark = req.body.passmark;
    var finalmark = req.body.finalmark;
    var subjectname = req.body.subjectname;
    var subject_author = req.body.subject_author;
    var subject_code = req.body.subject_code;
    var sql = `UPDATE subject SET class_name ="${class_name}",teacher_name = "${teacher_name}",type = "${type}",passmark = "${passmark}",finalmark = "${finalmark}",subjectname = "${subjectname}",subject_author = "${subject_author}",subject_code = "${subject_code}" WHERE subject_id = "${subject_id}"`;
    mysqlConnection.query(sql,(err,result)=>{
        if(!err) res.send(result);
        else console.log(err);
    })
});                                   




//  =================== Mail/Sms Code Start Here   ================
// app.post('/send',(req,res)=>{
//     // res.send(req.body);
//     // console.log(req.body);
// const from = '917418129254';
// const number = req.body.number;
// const text = req.body.text;

// // nexmo.message.sendSms(
// //     '+91 7418129254', number, text , {type : 'unicode'},
// //     (err, responseData) =>{
// //         if(err){
// //             console.log(err);
// //         }else{
// //             console.dir(responseData);
// //         }
// //     }
// // );

// nexmo.message.sendSms(from, number, text);


// });


app.post('/sms_send',(req,res)=>{
    var schoolyear =req.body.schoolyear ;
    var users =req.body.users ;
    var subject =req.body.subject ;
    var template =req.body.template ;
    var sendby =req.body.sendby ;
    var to_phone =req.body.to_phone ;
    var textmsg =req.body.textmsg ;
    var sql = `INSERT INTO mailsms (role,schoolyear,users,template,sendby,message) VALUES
     ("${schoolyear}","${users}","${subject}","${template}","${sendby}","${to_phone}","${textmsg}")`;
    mysqlConnection.query(sql,(err,result)=>{
        if(!err) res.send(result);
        else console.log(err);
    })
client.messages.create({
    body: textmsg,
    to: '+91'+ to_phone,
    from: '+12563877050' 
}).then(result => ({
    message: result
}))
.catch(err=> console.log(err));
})



app.post('/othersms_send_detail',(req,res)=>{
    var sql = `SELECT * FROM othersms`;
    mysqlConnection.query(sql,(err,result)=>{
        if(!err) res.send({
            message:result
        });
        else console.log(err);
    });

});

app.post('/othersms_send',(req,res)=>{
    var name =req.body.name ;
    var to_phone =req.body.to_phone ;
    var sendby =req.body.sendby ;
    var textmsg =req.body.textmsg ;
    console.log(to_phone);
    var sql = `INSERT INTO othersms (name,phone,sendby,message) VALUES
     ("${name}","${to_phone}","${sendby}","${textmsg}")`;
    mysqlConnection.query(sql,(err,result)=>{
        if(!err) res.send(result);
        else console.log(err);
    })
client.messages.create({
    body: textmsg,
    to: '+91'+ to_phone,
    from: '+12563877050' 
}).then(result => ({
    message: result
}))
.catch(err=> console.log(err));
})








//  =================== Mail/Sms Code End    Here   ===============

